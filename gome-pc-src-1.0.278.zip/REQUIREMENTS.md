# Gome PC 需求清单（用户立规：逐项记下来，做完逐项核对）

> 2026-10-07 用户立规：以后我说的需求都用文本单独记下来，然后把每一项需求都做出来，
> 做完后拿文本核对需求有没有做完，如果需求有冲突就来找我核对。
> 用户说过的需求直接做，不许再问"要不要做"。

## 需求列表

### UI 1:1 复制（2026-10-07 用户：PC UI 1:1 复刻安卓端）
- [x] 播放器页面 UI
- [x] 主页 UI
- [x] 详情页 UI
- [x] 搜索页 UI
- [x] 收藏页 UI
- [x] 设置页 UI
- [x] 资源库页 UI
- [x] 添加服务器弹窗 UI（按参考图，确认按钮"连接"蓝色）
- [x] 玩家菜单和剧集面板 UI

### 逻辑功能 1:1 复制（2026-10-07 03:18:29 用户："还有所有的逻辑功能全部在复制过去"）
- [x] 详情页5个按钮逻辑：已看/收藏/合集(版本)/音频(音轨)/评论(字幕)
- [x] 资源库应用锁：设置/验证/关闭 PIN
- [x] 资源库更多菜单：删除服务器
- [x] 服务器编辑：长按服务器卡片编辑
- [x] 搜索页服务器选择：聚合搜索药丸切换服务器
- [x] 媒体库详情跳转：主页媒体库卡片点击进详情页
- [x] 添加服务器连接：真实认证（非只保存配置）

### 短剧（2026-10-07 11:57:32 用户："短剧删掉，PC端不做"）
- [x] ~~短剧卡片/播放/管理~~ —— PC端不做，已删除

### README（2026-10-07 12:19 用户："下面的简介内容可以删掉吗"）
- [x] 删除 README.md 简介内容

### 播放器 Bug 修复（2026-10-07 用户反馈）
- [x] 剧集面板关不掉（2026-10-07 12:49 用户："弹窗卡片不消失，按钮功能点击无效"）
  - 加点外部关闭（对齐安卓 dim 点击）
  - 加 ESC 关闭（PC 适配）
  - 注意：不加 X 按钮（安卓没有，用户指出"自己乱加"）
- [ ] 进度条只有一半、按钮显示不全（2026-10-07 12:54 用户："进度条怎么只有一半，按钮显示不全"）
  - 根因：选集面板盖住右半边工具栏
  - 待验证：面板可关闭后是否正常
- [x] 左边按钮改全屏+音量（2026-10-07 13:13 用户："把左边的三个按钮删掉，改成全屏按钮和音量调节"）
  - 删除投屏/画面比例/旋转/锁定/倍速
  - 左边只留：全屏按钮 + 音量条
- [x] 下集和弹幕图标显示不全（2026-10-07 13:38 用户："下集按钮和弹幕按钮的图标都没显示全"）
  - 根因：VectorIcon的arc解析bug（1.0.59重画图标去arc）
- [x] 1G缓存没生效（2026-10-07 13:49 用户："怎么只缓存了这么一点，1G的缓存是不是没有生效"）
  - 根因：Prefs有缓存设置，但MpvPlayer.init()里没设置mpv的cache参数
  - 修复：init()加cacheEnabled/cacheSizeGb参数，设置cache=yes + demuxer-max-bytes=1G/2G/3G（对齐安卓）
- [x] 音量条改进度条样式（2026-10-07 13:52 用户："音量条改成进度条那种样式"）
  - 新建VolumeBar类：6dp轨道+14dp白圆，拖动调音量（同SeekBar样式）
- [x] 全屏模式工具栏无法呼出（2026-10-07 13:56 用户："点击全屏进入全屏模式后工具栏无法呼出"）
  - 改用AWT真全屏（GraphicsDevice.fullScreenWindow），标题栏去掉后鼠标事件正常
- [ ] 全屏模式顶部白条没去掉（2026-10-07 13:56 用户："顶部的白条还在，把它去掉"）
  - 1.0.61用undecorated导致闪退，已回滚（1.0.62）
  - 1.0.63改用JNA+Win32 SetWindowLongPtr修改窗口样式，不重建HWND（按Gemini分析建议）
  - 进入全屏：保存原style/bounds → 去WS_CAPTION/WS_THICKFRAME → 设为显示器完整bounds（覆盖任务栏）
  - 退出全屏：恢复原style/bounds
- [ ] 1.0.61工具栏不自动隐藏（2026-10-07 15:40 用户："忘说了1.0.61工具栏不自动隐藏"）
  - 根因：MPV鼠标哨兵Lua脚本高频触发mouse_move，工具栏刚隐藏278ms就被唤醒
  - 修复：删除哨兵脚本，AWT Canvas已有mouseMoved/mouseDragged/mouseClicked监听
- [x] 上下集和选集切换无效（2026-10-07 13:59 用户："点击上下集和选集卡片里面切换剧集无效"）
  - 根因：player用remember缓存，换集时还是旧player
  - 修复：remember(episodeId)，换集时销毁旧player建新player
- [x] 进度条满宽没做到（2026-10-07 14:08 用户："进度条满宽没做到"）
  - 根因：bottomBar用BoxLayout不撑满
  - 修复：改BorderLayout，progressRow放NORTH（1.0.57）
- [x] 按钮加半透明背板（2026-10-07 14:08 用户："全屏按钮圈内点击也没做到...给按钮加一个半透明背板"）
  - PlButton画几乎透明黑圆，整个32×32可点（1.0.57）
- [x] 全屏按钮加圈+整个圈可点击（2026-10-07 13:40 用户："给全屏按钮加上其它按钮同款的圈，然后整个圈内都是点击区域"）
  - 加圈：ic_pl_fullscreen.xml 加圆圈路径
  - 整个圈可点击：PlButton 加 contains override，整个32×32响应（用户13:44："它只能点击圈内的线条有效，改成整个圈内都有效"）

### Dock（用户：先复制安卓全部参数，再等比例放大适配PC）
- [ ] 核对安卓 Dock 真实实现（HostActivity/布局/drawable），再定 PC 参数
- [ ] M玻璃固定参数不得缩放：真模糊 radius 24f、#55FFFFFF、顶部高光、#AAFFFFFF 描边

### 发包流程（2026-10-07 用户立规）
- [ ] 发包前检查代码 10 遍
- [ ] 有问题修好后直接发，不用问用户
- [ ] 不要急着交作业

### 播放器顶栏（2026-10-07 16:35 用户："把电池图标删掉"）
- [x] 删除顶栏右上角电池图标（PC 无电池，画满格无意义）
  - AwtToolbarPanel：rightPanel 去掉 BatteryIcon，类一并删除

### 资源库页（2026-10-07 16:41 用户三条）
- [x] 删掉资源页右上角两个图标（锁 / 更多）
- [x] 点服务器卡片进主页，点服务器头像进编辑
  - ServerCard 加 onAvatarClick，头像 Box 单独 clickable
  - 2026-10-07 17:05 用户：点击服务器无效，不能进入主页
  - 根因：头像的 clickable 跟卡片的 combinedClickable 冲突
  - 修：头像改用 pointerInput + detectTapGestures
  - 2026-10-07 17:28 用户 1.0.70 仍无效
  - 根因：onServerSelected 只 reloadKey++，没跳 Screen.Home
  - 修：GridScreen 加 onServerSelected 参数，Main.kt 传 { screen = Screen.Home }
- [x] Dock 修好：太黑，拿安卓 M玻璃 参数
  - 根因：Robot 抓屏模糊抓到黑色，dock 发黑
  - 修：停用抓屏，直接按安卓参数画（#55FFFFFF 底 + #99FFFFFF→#00FFFFFF 高光 + #AAFFFFFF 描边）
  - 2026-10-07 17:03 用户：dock 太透，"又是你自己调的吗"
  - 根因：我多加了一层 Color.White(alpha=0.85f) 的底
  - 修：删掉自加的白底，只用 M玻璃 三件套
  - 2026-10-07 17:28 用户 1.0.70 仍不满意
  - 根因：M玻璃#55FFFFFF 是配 BlurView 真模糊的，PC 无真模糊时纯色太透
  - 修：Dock 用 DockTintNoBlur(#BFFFFFFF) 模拟毛玻璃糊感，高光描边不变
  - 2026-10-07 17:46 用户：第三方 dock 主题在 Win11 亚克力出来前就做出来了，PC 自己写真模糊
  - 修：DockBlurState 改用 Window.paint() 抓窗口内容（不用 Robot 抓屏），
    MGlassBox 补上 blurredBackdrop 绘制，Dock 换回标准 #55FFFFFF 底，
    Main.kt 加 500ms 定时更新模糊背景
  - 2026-10-07 18:01 用户 1.0.72"没有任何改变"，"高斯模糊去哪里了"
  - 根因：window.paint() 抓不到 Compose Skia 渲染的内容，模糊没生效
  - 修：改回 Robot，用 window.locationOnScreen 换算正确屏幕坐标，
    加全黑检测（抓失败时不更新）

### 编辑服务器弹窗（2026-10-07 16:58 用户："删除和图标功能啦？"）
- [x] 加删除按钮（编辑模式左下角红色）
- [x] 更换图标：搬安卓 ServerIconHelper（图标库下载+自动匹配+缓存+选择器）
  - Prefs 加 get/setCustomIconUrl
  - ServerIconHelper.kt（桌面版）：OkHttp+Skia，~/.gome/server_icons 缓存
  - IconPickerDialog：搜索+网格选择+清除自定义
  - AddServerDialog：编辑模式顶部图标预览+更换图标
  - ServerCard：头像显示自定义/自动匹配图标

### 主页只加载一次（2026-10-07 用户："主页的信息只有第一次启动的时候后台刷新，其它时候不要刷新"）
- [x] HomeDataCache 单例：libs/libItems/resume/latest 只在第一次启动时后台加载一次
- [x] HomeScreen 改用缓存，切回主页不再触发刷新
- [x] 出错时可手动重试

### 资源库砍掉多余刷新（2026-10-07 用户："把资源库的刷新砍了"）
- [x] GridScreen 删除 LaunchedEffect（拉媒体库列表+每库4张图，但页面显示的是服务器卡片，数据从没用上）
- [x] GridScreen 简化为直接显示 ServerCardsGrid（本地数据，无网络请求）
- [x] 用户确认：资源库页只需要点击服务器跳转到主页

### 轮播图顶到窗口最上沿（2026-10-07 用户："顶部还留一段空白区域干嘛"）
- [x] LazyColumn 去掉顶部和水平 contentPadding，轮播图全宽置顶
- [x] 继续观看/媒体库/各库分区各自加 20dp 水平内边距

### 主页缓存按服务器隔离（2026-10-07 用户："是你播放器的问题"——主页卡加载）
- [x] HomeDataCache 记录 serverKey（协议+host+端口+路径+用户名），服务器变了自动清空重载
- [x] retry() 同步 serverKey，避免 loading 卡死

### 图片加载换 HttpURLConnection（2026-10-07 用户："下面的信息都加载不出来"——海报灰框）
- [x] EmbyImageLoader 改用 HttpURLConnection（OkHttp 在部分服务器 unexpected end of stream，数据接口早已换，图片漏了）
